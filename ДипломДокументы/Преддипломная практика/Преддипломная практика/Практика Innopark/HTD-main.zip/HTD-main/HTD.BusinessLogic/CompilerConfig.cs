﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("HTD.App")]