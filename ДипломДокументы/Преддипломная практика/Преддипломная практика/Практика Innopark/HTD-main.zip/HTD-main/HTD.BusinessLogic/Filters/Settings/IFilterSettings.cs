﻿namespace HTD.BusinessLogic.Filters.Settings
{
    internal interface IFilterSettings<T>
        where T : class
    {
    }
}
