﻿namespace HTD.BusinessLogic.Models
{
    public class CourseTypeModel : IModel
    {
        public string NameTB { get; set; }
    }
}
