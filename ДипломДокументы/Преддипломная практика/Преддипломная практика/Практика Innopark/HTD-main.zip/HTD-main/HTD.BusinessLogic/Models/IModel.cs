﻿namespace HTD.BusinessLogic.Models
{
    public interface IModel
    {
    }
}
