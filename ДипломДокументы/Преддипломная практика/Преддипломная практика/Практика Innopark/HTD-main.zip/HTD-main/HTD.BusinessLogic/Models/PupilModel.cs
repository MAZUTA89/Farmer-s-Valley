﻿namespace HTD.BusinessLogic.Models
{
    internal class PupilModel : IModel
    {
        public string NameTB { get; set; }

        public string BirthDayDP { get; set; }

        public string ParentNameTB { get; set; }

        public string ContactPhoneTB { get; set; }
    }
}
