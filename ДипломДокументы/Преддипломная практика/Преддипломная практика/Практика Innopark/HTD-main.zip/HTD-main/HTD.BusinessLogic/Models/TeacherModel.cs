﻿namespace HTD.BusinessLogic.Models
{
    internal class TeacherModel : IModel
    {
        public string NameTB { get; set; }

        public string PhoneTB { get; set; }

        public string StartWorkDateDP { get; set; }
    }
}
