﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("HTD.BusinessLogic")]